
import org.junit.jupiter.api.Test;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

class VehicleTest {
    Vehicle vehicle = new Vehicle(1,2010, "Honda", "City");
    Vehicle vehicle2 = new Vehicle(0,2000, "Toyato", "Corolla");

    @org.junit.jupiter.api.Test
    void testToString() {
        assertEquals(vehicle.toString(), "1 2010 Honda City");
    }

    @Test
    void vehicleList() {
        HashMap<Integer, Vehicle> list = new HashMap<Integer, Vehicle>();
        list.put(1, vehicle);
        list.put(0, vehicle2);
        assertEquals(list, Vehicle.vehicleList());
    }

    @org.junit.jupiter.api.Test
    void find() {
        assertEquals(vehicle, Vehicle.find(01));
    }

    @org.junit.jupiter.api.Test
    void isEmpty() {
        assertFalse(Vehicle.isEmpty());
    }

    @org.junit.jupiter.api.Test
    void getId() {
        assertEquals(vehicle.getId(), 1);
    }

    @org.junit.jupiter.api.Test
    void setId() {
        vehicle2.setId(2);
        assertEquals(2,vehicle2.getId());
    }

    @org.junit.jupiter.api.Test
    void getYear() {
        assertEquals(vehicle.getYear(), 2010);
    }

    @org.junit.jupiter.api.Test
    void setYear() {
        vehicle2.setYear(2020);
        assertEquals(2020,vehicle2.getYear());
    }

    @org.junit.jupiter.api.Test
    void getMake() {
        assertEquals(vehicle.getMake(), "Honda");
    }

    @org.junit.jupiter.api.Test
    void setMake() {
        vehicle2.setMake("Toyota");
        assertEquals("Toyota",vehicle2.getMake());
    }

    @org.junit.jupiter.api.Test
    void getModel() {
        assertTrue(vehicle.getModel().equals("City"));
    }

    @org.junit.jupiter.api.Test
    void setModel() {
        vehicle2.setModel("Corola");
        assertEquals("Corola",vehicle2.getModel());
    }

    @org.junit.jupiter.api.Test
    void removeVehicle() {
        vehicle.removeVehicle();
        assertNull(Vehicle.find(1));
    }

    @org.junit.jupiter.api.Test
    void clear() {
        Vehicle.clear();
        assertTrue(Vehicle.isEmpty());
    }
}