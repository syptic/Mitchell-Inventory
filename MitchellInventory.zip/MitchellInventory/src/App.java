import java.io.Serializable;
import java.util.Scanner; // Import the Scanner class

/* Driver for Vehicle class to maintain inventory*/
public class App {
    public static void main(String[] args) {
        Vehicle.init(); // Read existing inventory
        Scanner s = new Scanner(System.in); // Declare Scanner for user input

        // Variables for different functions
        int id, year;
        String model, make;
        Vehicle vehicle;

        System.out.println("Welcome to the Vehicle Inventory Program!");
        while (true) { // Take user input
            System.out.println( // User options
                    "Enter Your Command:\n1- Add new vehicle\n2- Search vehicles(id)"+
                            "\n3- Update existing vehicle\n4- Get Vehicle List"+
                            "\n5- Remove a vehicle\n6- Empty Vehicle List+" +
                            "\n7- Filter vehicles\n0- exit program");
            if (!s.hasNext()) { // No input condition
                break;
            }
            int input = s.nextInt(); // Read user command

            if (input == 0) { // Exit Condition
                System.out.println("Have a good day!");
                break;
            }
            switch (input) {
                case 1: // New vehicle
                    System.out.println("New vehicle details:");
                    // Vehicle id check
                    System.out.print("Vehicle Id:");
                    id = s.nextInt();
                    if(Vehicle.find(id) != null){ //Duplicate id case
                        System.out.println("Duplicate id, vehicle already exists!");
                        break;
                    }
                    // Other vehicle properties
                    System.out.print("Vehicle Year:");
                    year = s.nextInt();
                    s.nextLine();
                    System.out.print("Vehicle Make:");
                    make = s.nextLine();
                    System.out.print("Vehicle Model:");
                    model = s.nextLine();
                    try {
                        new Vehicle(id, year, make, model);
                    } catch(IllegalArgumentException ex){
                        System.out.println(ex.getMessage());
                        System.out.println("Vehicle can't be created!");
                        break;
                    }
                    // Succ Msg
                    System.out.println("New vehicle " + id + " created!");
                    break;

                case 2: // Search Vehicle
                    if(Vehicle.isEmpty()){ // null case
                        System.out.println("No vehicles in inventory");
                        break;
                    }
                    vehicle = search(s);
                    if(vehicle == null){ // if vehicle exists
                        System.out.println("Vehicle not found! Please check id and try again.");
                    } else{
                        System.out.println("Vehicle found: "+vehicle);
                    }
                    break;

                case 3: // Update vehicle
                    if(Vehicle.isEmpty()){ // null case
                        System.out.println("No vehicles in inventory");
                        break;
                    }
                    vehicle = search(s);
                    if(vehicle == null){ // if vehicle exists
                        System.out.println("Vehicle not found! Please check id and try again.");
                        break;
                    }
                    System.out.print("Enter edit property( 1:year, 2:make, 3:model):"); // vehicle property to edit
                    input = s.nextInt();
                    System.out.print("\nEnter value:");
                    switch (input) {
                        case 1:
                            year = s.nextInt();
                            try {
                                vehicle.setYear(year);
                            } catch(IllegalArgumentException ex){
                                System.out.println(ex.getMessage());
                                System.out.println("Can't update Year!");
                                break;
                            }
                            System.out.println("Year Updated to " + year);
                            break;
                        case 2:
                            make = s.nextLine();
                            try {
                                vehicle.setMake(make);
                            } catch(IllegalArgumentException ex){
                                System.out.println(ex.getMessage());
                                System.out.println("Can't update Make!");
                                break;
                            }
                            System.out.println("Year Updated to " + make);
                            break;
                        case 3:
                            model = s.nextLine();
                            try {
                                vehicle.setModel(model);
                            } catch(IllegalArgumentException ex){
                                System.out.println(ex.getMessage());
                                System.out.println("Can't update Model!");
                                break;
                            }
                            System.out.println("Year Updated to " + model);
                            break;
                        default:
                            System.out.println("\nIncorrect choice, try again.");
                            break;
                    }
                    break;

                case 4: // vehicle list
                    if(Vehicle.isEmpty()){ // null case
                        System.out.println("No vehicles in inventory");
                        break;
                    }
                    for (int i : Vehicle.vehicleList().keySet()) {
                        System.out.println("Vehicle id: " + i);
                    }
                    break;

                case 5: // Remove Vehicle
                    if(Vehicle.isEmpty()){ // null case
                        System.out.println("No vehicles in inventory");
                        break;
                    }
                    vehicle = search(s);
                    if(vehicle != null) { // vehicle doesnt exist case
                        vehicle.removeVehicle();
                        System.out.println("Vehicle Removed");
                    } else{
                        System.out.println("Vehicle not found! Please check id and try again.");
                    }
                    break;

                case 6: // Clear inventory
                    if(Vehicle.isEmpty()){ // already empty case
                        System.out.println("Inventory already empty");
                    } else{
                        Vehicle.clear(); // succ case
                        System.out.println("Inventory cleared!");
                    }
                    break;

                case 7:
                    if(Vehicle.isEmpty()){ // null case
                        System.out.println("No vehicles in inventory");
                        break;
                    }
                    System.out.print("Enter filter property( 1:year, 2:make, 3:model):"); // vehicle property to edit
                    input = s.nextInt();
                    s.nextLine();
                    System.out.print("\nEnter value:");
                    switch (input) {
                        case 1:
                            year = s.nextInt();
                            for (Vehicle v: Vehicle.vehicleList().values()
                                 ) {
                                if(v.getYear() == year){
                                    System.out.println("Vehicle Id:"+v.getId());
                                }
                            }
                            break;
                        case 2:
                            make = s.nextLine();
                            for (Vehicle v: Vehicle.vehicleList().values()
                            ) {
                                if(v.getMake().equals(make)){
                                    System.out.println("Vehicle Id:"+v.getId());
                                }
                            }
                            break;
                        case 3:
                            model = s.nextLine();
                            for (Vehicle v: Vehicle.vehicleList().values()
                            ) {
                                if(v.getModel().equals(model)){
                                    System.out.println("Vehicle Id:"+v.getId());
                                }
                            }
                            break;
                        default:
                            System.out.println("\nIncorrect choice, try again.");
                            break;
                    }
                    break;

                default:
                    System.err.println("Invalid input. Please Try Again."); // invalid input
                    break;
            }
            System.out.println();
        }
        s.close();
        Vehicle.save(); // Write vehicles to file
    }
    private static Vehicle search(Scanner s){ // helper method to search for vehicle
        System.out.print("Vehicle Id:");
        int id = s.nextInt();
        return (Vehicle.find(id));
    }
}
