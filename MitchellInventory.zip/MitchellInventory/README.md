Welcome to my Coding Challenge Submission for Mitchell Interntaional!

I'd like to start by thanking you for this opportunity and take you through this project.
I have implemented the task in Java and created the project in intelliJ. I used Serializable(Java) for in-memory
persistence and Junit for automated testing(VehicleTest.java).
App.java is my driver for this project and the main file you can use to go through the project.

Instructions(I suggest the following for best results): 
	1. Open folder as intelliJ project 
	2. Compile and Run the project(App.main()) 
	3. Run VehicleTest.java to run unit tests and get results

Executable(jar) provided in out/production for your choice!
