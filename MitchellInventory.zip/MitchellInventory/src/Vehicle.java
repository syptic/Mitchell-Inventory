
import org.w3c.dom.ranges.RangeException;

import java.io.*;
import java.security.InvalidParameterException;
import java.time.Year;
import java.util.*;

/* Vehicle Class representing objects in inventory*/
public class Vehicle implements Serializable{
  private static final String filePath = "vehicleList.ser";
  private static final long serialVersionUID = 6529685098267757690L; // serialID for objects used for memory persistence
  private static HashMap<Integer, Vehicle> inventory = new HashMap<Integer, Vehicle>();
  private int id; // private = restricted access to vehicle id
  private int year; // private = restricted access to vehicle year
  private String make; // private = restricted to vehicle make
  private String model; // private = restricted access to vehicle model

  @Override
  public String toString() { // override method to write vehicle properties
    return this.getId() + " " + this.getYear() + " " + this.getMake() + " " + this.getModel();
  }

  // ctor
  public Vehicle(int id, int year, String make, String model) throws IllegalArgumentException {
    this.setId(id); // vehicle unique id
    this.setYear(year); // vehicle manu. year
    this.setMake(make); // vehicle make company
    this.setModel(model); // vehicle model name
    inventory.put(id, this); // add vehicle to inventory
  }

  // inventory list
  public static HashMap<Integer, Vehicle> vehicleList() {
    return inventory;
  }

  // find vehicle
  public static Vehicle find(int id) {
    return inventory.get(id);
  }

  // isEmpty inventory
  public static boolean isEmpty(){
    return inventory.isEmpty();
  }

  /* Id methods: */
  // Getter
  public int getId() {
    return this.id;
  }
  // Setter
  public void setId(int id) {
    this.id = id;
  }

  /* Year methods: */
  // Getter
  public int getYear() {
    return year;
  }
  // Setter
  public void setYear(int year) throws IllegalArgumentException{
    if(year<= 2050 && year>=1950) {
      this.year = year;
    } else{
      throw new IllegalArgumentException("Year has to be between 1950-2050");
    }
  }

  /* Make methods: */
  // Getter
  public String getMake() {
    return make;
  }
  // Setter
  public void setMake(String make) {
    if(make == null || make.replaceAll("\\s","").equals("")) {
      throw new IllegalArgumentException("Make can not be null/empty");
    } else{
      this.make = make;
    }
  }

  /* Model methods: */
  // Getter
  public String getModel() {
    return model;
  }
  // Setter
  public void setModel(String model) {
    if(model == null || model.replaceAll("\\s","").equals("")) {
      throw new IllegalArgumentException("Model can not be null/empty");
    } else{
      this.model = model;
    }
  }

  // dtor
  public void removeVehicle() {
    inventory.remove(this.id);
  }

  // empty inventory
  public static void clear() {
    inventory.clear();
  }

  // Read existing inventory
  public static void init(){
    try {
      File f = new File(filePath); // data file
      if(f.exists()) { // if inventory exists
        FileInputStream fi = new FileInputStream(f); // open file
        ObjectInputStream oi = new ObjectInputStream(fi); // read file
        while (true) {    // Read vehicles
          try {
            Vehicle v = (Vehicle) oi.readObject();
            Vehicle.inventory.put(v.id, v); // list vehicles to inventory
          }catch(EOFException ex){
            break;
          }
        }
        oi.close();
        fi.close();
      }
    } catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  // Save current inventory
  public static void save(){
    try {
      File f = new File(filePath); // data file
      f.createNewFile(); // if file doesn;t exist
      FileOutputStream fileOut = new FileOutputStream(f); // open file
      ObjectOutputStream objectOut = new ObjectOutputStream(fileOut); // write to file
      for (Vehicle v: inventory.values()) { // write all vehicles
        objectOut.writeObject(v);
      }
      objectOut.close();
      fileOut.close();
      System.out.println("The Inventory was succesfully saved."); // Succ msg
    } catch (Exception ex) {
      ex.printStackTrace();
    }
  }
}